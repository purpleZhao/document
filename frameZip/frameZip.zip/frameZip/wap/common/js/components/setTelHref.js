/**
 * 设置客服电话
 * @author 杨金来 2017-04-05
 */

$('.telHref').attr('href', 'tel:'+commonSetting.serverPhone ).html(commonSetting.serverPhone );